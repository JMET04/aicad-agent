# cliff-villa-three-floor-diagnostic-v112 - AICAD multi-view audit

- Space/domain: `2d` / `architecture`
- Source SHA-256: `2348f84b9172e225229853f12ac6a1a91332cd1f96b3793104365284b851c929`
- View count: `3`
- Selection mappings: `2146`
- Model coordinate system: `MODEL_XYZ` / `right-handed` / `mm`
- Typed measurements: `2146` / `2146`
- Coordinate display toggle: `present` (SVG views + 3D selector)
- Exact 3D selector subobjects: `0`
- Review HTML UTF-8/mojibake gate: `pass`
- Visible stroke / independent hit tolerance: `0.8px / 12px`
- Native persistent topology authority: `false` (plan-derived semantic subobjects)

| View | Kind | Geometry scope | Entities | Lost axis | Manufacturing authority |
|---|---|---|---:|---|---|
| `STOREY_LF` | `native_2d` | `authoritative_2d_geometry` | 697 | `None` | `False` |
| `STOREY_MF` | `native_2d` | `authoritative_2d_geometry` | 904 | `None` | `False` |
| `STOREY_UF` | `native_2d` | `authoritative_2d_geometry` | 545 | `None` | `False` |

Projection entities are review proxies with semantic back-references. Native host evidence remains required before production use.
