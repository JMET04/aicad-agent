# srb160_bounded_envelope-review - AICAD multi-view audit

- Space/domain: `2d` / `mechanical`
- Source SHA-256: `7938b72232c4ca95968f28c8c362b362b5ef365fcca64c51b8b641d94c98510f`
- View count: `1`
- Selection mappings: `5`
- Model coordinate system: `MODEL_XYZ` / `right-handed` / `mm`
- Typed measurements: `5` / `5`
- Coordinate display toggle: `present` (SVG views + 3D selector)
- Exact 3D selector subobjects: `0`
- Review HTML UTF-8/mojibake gate: `pass`
- Visible stroke / independent hit tolerance: `0.8px / 12px`
- Native persistent topology authority: `false` (plan-derived semantic subobjects)

| View | Kind | Geometry scope | Entities | Lost axis | Manufacturing authority |
|---|---|---|---:|---|---|
| `PLAN` | `native_2d` | `authoritative_2d_geometry` | 5 | `None` | `False` |

Projection entities are review proxies with semantic back-references. Native host evidence remains required before production use.
