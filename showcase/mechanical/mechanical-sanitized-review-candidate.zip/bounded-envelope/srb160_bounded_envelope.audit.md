# srb160_bounded_envelope - AI CAD audit

- Schema: `2.0`
- Domain: `mechanical`
- Units: `mm`
- Origin: `(0, 0)`
- Tolerance: `1e-06`
- Source SHA-256: `7938b72232c4ca95968f28c8c362b362b5ef365fcca64c51b8b641d94c98510f`
- Entity count: `5`

| # | ID | Type | Layer | Roles | Depends on | Editable | Purpose | Geometry | Constraints | Reasoning |
|---:|---|---|---|---|---|---|---|---|---|---|
| 1 | `N_DATUM` | `line` | `DATUM` | datum | origin | `true` | Real datum extension at the base corner | `(0, 0) -> (0, -10); L=10` | start_coincident=origin; vertical; length=10 | Provides the mandatory origin-first entity without overlapping the production envelope. |
| 2 | `NB1` | `line` | `OUTLINE` | outline | N_DATUM | `true` | Bounded base envelope bottom | `(0, 0) -> (160, 0); L=160` | start_coincident=origin; horizontal; length=160 | The physical 160 mm base begins at origin. |
| 3 | `NB2` | `line` | `OUTLINE` | outline | NB1 | `true` | Bounded base envelope right | `(160, 0) -> (160, 130); L=130` | start_coincident=NB1.end; vertical; length=130 | Continues 130 mm perpendicular to the bottom edge. |
| 4 | `NB3` | `line` | `OUTLINE` | outline | NB2 | `true` | Bounded base envelope top | `(160, 130) -> (0, 130); L=160` | start_coincident=NB2.end; horizontal; length=160 | Returns parallel to the bottom edge at the declared height. |
| 5 | `NB4` | `line` | `OUTLINE` | outline | NB3, NB1 | `true` | Bounded base envelope left closure | `(0, 130) -> (0, 0); L=130` | start_coincident=NB3.end; end_coincident=origin; vertical; length=130 | Closes the single simple production envelope exactly at origin. |
