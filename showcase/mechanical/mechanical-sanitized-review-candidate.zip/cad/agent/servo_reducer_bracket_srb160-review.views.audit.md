# servo_reducer_bracket_srb160-review - AICAD multi-view audit

- Space/domain: `2d` / `mechanical`
- Source SHA-256: `f60bd50c712f6b911a7b5b090b1a0dd7cdbd89d3cbd1b2230ae060b9b21604f9`
- View count: `1`
- Selection mappings: `229`
- Model coordinate system: `MODEL_XYZ` / `right-handed` / `mm`
- Typed measurements: `229` / `229`
- Coordinate display toggle: `present` (SVG views + 3D selector)
- Exact 3D selector subobjects: `0`
- Review HTML UTF-8/mojibake gate: `pass`
- Visible stroke / independent hit tolerance: `0.8px / 12px`
- Native persistent topology authority: `false` (plan-derived semantic subobjects)

| View | Kind | Geometry scope | Entities | Lost axis | Manufacturing authority |
|---|---|---|---:|---|---|
| `PLAN` | `native_2d` | `authoritative_2d_geometry` | 229 | `None` | `False` |

Projection entities are review proxies with semantic back-references. Native host evidence remains required before production use.
