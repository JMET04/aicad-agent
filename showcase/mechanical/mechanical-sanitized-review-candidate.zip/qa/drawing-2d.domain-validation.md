# drawing-2d - AICAD domain validation

- Status: `passed_with_warnings`
- Domain / space: `mechanical` / `2d`
- Failures / warnings: `0` / `147`

| Rule | Status | Severity | Objects | Result |
|---|---|---|---|---|
| `DOMAIN.G001` | `pass` | `hard` | - | The plan compiled and its ordered semantic dependency graph is valid. |
| `DOMAIN.G002` | `warning` | `advisory` | FRAME_BOTTOM | FRAME_BOTTOM uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | FRAME_RIGHT | FRAME_RIGHT uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | FRAME_TOP | FRAME_TOP uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | FRAME_LEFT | FRAME_LEFT uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | TITLE_TOP | TITLE_TOP uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | TITLE_V1 | TITLE_V1 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | TITLE_V2 | TITLE_V2 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | TITLE_V3 | TITLE_V3 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | TITLE_V4 | TITLE_V4 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | TITLE_H1 | TITLE_H1 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | TITLE_H2 | TITLE_H2 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | TITLE_H3 | TITLE_H3 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SHEET_TITLE | SHEET_TITLE uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | CUT_A_LEFT | CUT_A_LEFT uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | CUT_A_RIGHT | CUT_A_RIGHT uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | CUT_ARROW_L1 | CUT_ARROW_L1 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | CUT_ARROW_L2 | CUT_ARROW_L2 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | CUT_ARROW_R1 | CUT_ARROW_R1 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | CUT_ARROW_R2 | CUT_ARROW_R2 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | CUT_A_LABEL_L | CUT_A_LABEL_L uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | CUT_A_LABEL_R | CUT_A_LABEL_R uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | TOP_VIEW_LABEL | TOP_VIEW_LABEL uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | DIM_BASE_W | DIM_BASE_W uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | DIM_BASE_H | DIM_BASE_H uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | TOP_FLANGE_MARK_L | TOP_FLANGE_MARK_L uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | TOP_FLANGE_MARK_R | TOP_FLANGE_MARK_R uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | DIM_FLANGE_D | DIM_FLANGE_D uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | FRONT_BORE_L | FRONT_BORE_L uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | FRONT_BORE_R | FRONT_BORE_R uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | FRONT_REGISTER_L | FRONT_REGISTER_L uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | FRONT_REGISTER_R | FRONT_REGISTER_R uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | FRONT_LABEL | FRONT_LABEL uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | DIM_TOTAL_H | DIM_TOTAL_H uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | DIM_BASE_T | DIM_BASE_T uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | RIGHT_BORE_L | RIGHT_BORE_L uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | RIGHT_BORE_R | RIGHT_BORE_R uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | RIGHT_REGISTER_L | RIGHT_REGISTER_L uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | RIGHT_REGISTER_R | RIGHT_REGISTER_R uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | RIGHT_LABEL | RIGHT_LABEL uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_BOTTOM | SEC_BOTTOM uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_LEFT | SEC_LEFT uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_RIGHT | SEC_RIGHT uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_TOP_1 | SEC_TOP_1 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_TOP_2 | SEC_TOP_2 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_TOP_3 | SEC_TOP_3 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_TOP_4 | SEC_TOP_4 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_BORE_L | SEC_BORE_L uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_BORE_R | SEC_BORE_R uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_REG_L | SEC_REG_L uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_REG_R | SEC_REG_R uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_LEDGE_L | SEC_LEDGE_L uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_LEDGE_R | SEC_LEDGE_R uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_BCD_L_IN | SEC_BCD_L_IN uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_BCD_L_OUT | SEC_BCD_L_OUT uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_CB_L_IN | SEC_CB_L_IN uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_CB_L_OUT | SEC_CB_L_OUT uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_CB_L_LEDGE1 | SEC_CB_L_LEDGE1 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_CB_L_LEDGE2 | SEC_CB_L_LEDGE2 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_BCD_R_IN | SEC_BCD_R_IN uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_BCD_R_OUT | SEC_BCD_R_OUT uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_CB_R_IN | SEC_CB_R_IN uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_CB_R_OUT | SEC_CB_R_OUT uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_CB_R_LEDGE1 | SEC_CB_R_LEDGE1 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_CB_R_LEDGE2 | SEC_CB_R_LEDGE2 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_1_01 | HATCH_LOW_1_01 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_1_02 | HATCH_LOW_1_02 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_1_03 | HATCH_LOW_1_03 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_1_04 | HATCH_LOW_1_04 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_1_05 | HATCH_LOW_1_05 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_1_06 | HATCH_LOW_1_06 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_1_07 | HATCH_LOW_1_07 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_1_08 | HATCH_LOW_1_08 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_1_09 | HATCH_LOW_1_09 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_1_10 | HATCH_LOW_1_10 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_1_11 | HATCH_LOW_1_11 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_1_12 | HATCH_LOW_1_12 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_1_13 | HATCH_LOW_1_13 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_1_14 | HATCH_LOW_1_14 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_2_01 | HATCH_LOW_2_01 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_2_02 | HATCH_LOW_2_02 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_2_03 | HATCH_LOW_2_03 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_2_04 | HATCH_LOW_2_04 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_2_05 | HATCH_LOW_2_05 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_2_06 | HATCH_LOW_2_06 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_2_07 | HATCH_LOW_2_07 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_2_08 | HATCH_LOW_2_08 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_2_09 | HATCH_LOW_2_09 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_3_01 | HATCH_LOW_3_01 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_3_02 | HATCH_LOW_3_02 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_3_03 | HATCH_LOW_3_03 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_3_04 | HATCH_LOW_3_04 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_3_05 | HATCH_LOW_3_05 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_3_06 | HATCH_LOW_3_06 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_3_07 | HATCH_LOW_3_07 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_3_08 | HATCH_LOW_3_08 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_3_09 | HATCH_LOW_3_09 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_4_01 | HATCH_LOW_4_01 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_4_02 | HATCH_LOW_4_02 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_4_03 | HATCH_LOW_4_03 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_4_04 | HATCH_LOW_4_04 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_4_05 | HATCH_LOW_4_05 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_4_06 | HATCH_LOW_4_06 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_4_07 | HATCH_LOW_4_07 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_4_08 | HATCH_LOW_4_08 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_4_09 | HATCH_LOW_4_09 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_4_10 | HATCH_LOW_4_10 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_4_11 | HATCH_LOW_4_11 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_4_12 | HATCH_LOW_4_12 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_4_13 | HATCH_LOW_4_13 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_LOW_4_14 | HATCH_LOW_4_14 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_TOP_1_01 | HATCH_TOP_1_01 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_TOP_1_02 | HATCH_TOP_1_02 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_TOP_1_03 | HATCH_TOP_1_03 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_TOP_1_04 | HATCH_TOP_1_04 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_TOP_1_05 | HATCH_TOP_1_05 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_TOP_1_06 | HATCH_TOP_1_06 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_TOP_1_07 | HATCH_TOP_1_07 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_TOP_1_08 | HATCH_TOP_1_08 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_TOP_2_01 | HATCH_TOP_2_01 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_TOP_2_02 | HATCH_TOP_2_02 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_TOP_3_01 | HATCH_TOP_3_01 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_TOP_3_02 | HATCH_TOP_3_02 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_TOP_4_01 | HATCH_TOP_4_01 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_TOP_4_02 | HATCH_TOP_4_02 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_TOP_4_03 | HATCH_TOP_4_03 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_TOP_4_04 | HATCH_TOP_4_04 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_TOP_4_05 | HATCH_TOP_4_05 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_TOP_4_06 | HATCH_TOP_4_06 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_TOP_4_07 | HATCH_TOP_4_07 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | HATCH_TOP_4_08 | HATCH_TOP_4_08 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | SEC_LABEL | SEC_LABEL uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | DIM_SEC_H | DIM_SEC_H uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | NOTE_1 | NOTE_1 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | NOTE_2 | NOTE_2 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | NOTE_3 | NOTE_3 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | NOTE_4 | NOTE_4 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | NOTE_5 | NOTE_5 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | TB_NAME | TB_NAME uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | TB_DRAWING | TB_DRAWING uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | TB_MATERIAL | TB_MATERIAL uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | TB_STATUS | TB_STATUS uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | TB_SCALE | TB_SCALE uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | TB_UNITS | TB_UNITS uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | TB_SHEET | TB_SHEET uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | TB_PROJ | TB_PROJ uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | TB_LOCK | TB_LOCK uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.G002` | `warning` | `advisory` | NOTE_6 | NOTE_6 uses roles outside the built-in mechanical vocabulary. |
  - Root cause: The generator introduced a role without binding it to the active domain profile.
  - Prevention candidate (disabled): Require every generated role to be declared by the active domain rule pack or explicitly registered as a reviewed extension.
| `DOMAIN.2D.CLOSED.OUTLINE` | `pass` | `hard` | FRONT_OUTER_BOTTOM, FRONT_OUTER_LEFT, FRONT_OUTER_RIGHT, FRONT_OUTER_TOP, RIGHT_OUTER_BOTTOM, RIGHT_OUTER_LEFT, RIGHT_OUTER_RIGHT, RIGHT_OUTER_TOP, TOP_BASE_BOTTOM, TOP_BASE_LEFT, TOP_BASE_RIGHT, TOP_BASE_TOP | The outline line set is closed. |

## Manual review queue

- datums
- fit
- wall_thickness
- interference
- tolerance
