# model-3d - AICAD domain validation

- Status: `passed`
- Domain / space: `mechanical` / `3d`
- Failures / warnings: `0` / `0`

| Rule | Status | Severity | Objects | Result |
|---|---|---|---|---|
| `DOMAIN.G001` | `pass` | `hard` | - | The plan compiled and its ordered semantic dependency graph is valid. |
| `DOMAIN.3D.001` | `pass` | `hard` | F_BASE, F_FLANGE_BOSS, F_RIB_EAST, F_RIB_WEST, F_RIB_NORTH, F_RIB_SOUTH, F_BEARING_BORE, F_REGISTER_RECESS, F_BCD_THROUGH, F_BCD_COUNTERBORE, F_ANCHOR_TOP, F_ANCHOR_BOTTOM, F_POCKET_SW, F_RELIEF_PATTERN, F_DOWEL_PAIR, F_LUBE_PORT | Every feature transaction preserves a valid single solid and analytic state. |

## Manual review queue

- datums
- fit
- wall_thickness
- interference
- tolerance
