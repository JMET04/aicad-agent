# model-3d - AICAD multi-view audit

- Space/domain: `3d` / `mechanical`
- Source SHA-256: `ea4a079310865d8a69e5210512537b3ca4070a996d465f7eb751389bbf39405a`
- View count: `6`
- Selection mappings: `820`
- Model coordinate system: `MODEL_XYZ` / `right-handed` / `mm`
- Typed measurements: `820` / `820`
- Coordinate display toggle: `present` (SVG views + 3D selector)
- Exact 3D selector subobjects: `312`
- Review HTML UTF-8/mojibake gate: `pass`
- Visible stroke / independent hit tolerance: `0.8px / 12px`
- Native persistent topology authority: `false` (plan-derived semantic subobjects)

| View | Kind | Geometry scope | Entities | Lost axis | Manufacturing authority |
|---|---|---|---:|---|---|
| `TOP` | `orthographic` | `feature_profiles_before_final_visibility` | 76 | `z` | `False` |
| `FRONT` | `orthographic` | `feature_operation_extents` | 80 | `y` | `False` |
| `RIGHT` | `orthographic` | `feature_operation_extents` | 80 | `x` | `False` |
| `ISOMETRIC` | `isometric` | `selectable_feature_extent_proxy` | 192 | `depth` | `False` |
| `SECTION_X0` | `section` | `feature_operation_section` | 40 | `None` | `False` |
| `SECTION_Y0` | `section` | `feature_operation_section` | 40 | `None` | `False` |

Projection entities are review proxies with semantic back-references. Native host evidence remains required before production use.
