# 公开审查需求合同

- 96 × 72 mm、四层工业混合信号控制器。
- 24 V 防护、5 V 降压、3.3 V LDO、MCU、USB-C FS、RS-485、四路模拟输入、SWD、LED、测试点。
- 真实 KiCad 工程文本、板框、丝印、安装孔、网络类、走线、过孔和内层 GND/PWR 覆铜。
- 输出原理图/PCB/交叉/热/EMC/Gerber/制造门禁/独立几何证据、中文审查、清单与哈希。
- 关键器件仅使用厂家官方数据表链接。
- 公开候选证据只允许发布相对路径；不得包含本机目录、凭据或禁用品牌词。
- 固定门禁：reviewOnly=true，accepted=false，ruleEnabled=false，packagingGated=true，fabricationReady=false。
