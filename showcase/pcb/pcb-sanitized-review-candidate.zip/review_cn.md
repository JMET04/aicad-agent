# 工业混合信号控制器全量审查

审查日期：2026-08-12  
用途：公开展示与设计审查候选  
结论：**禁止投板，禁止解除封装门禁。**

## 阻断结论

固定状态为 `reviewOnly=true`、`accepted=false`、`ruleEnabled=false`、`packagingGated=true`、`fabricationReady=false`。本包可以公开上传用于审查，但不构成制造授权。

1. 环境没有可用的原生工程命令行工具，因此没有原生 ERC、DRC、覆铜重填、制造文件重导出或原生 3D 证据。
2. 独立二维铜线段检查实际比较 11,503 个同层异网线段对，在 0.18 mm 保守下限下记录 0 个间距不足或交叠事件；未发现需列出的违规网对；该检查通过，但未路由和缺原生 DRC 仍阻断。
3. 原理图分析器记录 1 个采购错误：唯一料号覆盖仅 9/52；制造门禁另记录 76 个器件缺料号。
4. USB-C 插座仍是 `REVIEW_ONLY` 占位封装，生产料号、焊盘、外壳固定脚和机械图尚未锁定。
5. USB 阻抗尚无板厂叠层与场求解器结果；当前 0.20 mm 线宽/0.15 mm 间距只能视为意图值。
6. 没有 SPICE 引擎；热分析器实际评估元件数为 0，不能把 100 分表面值解释为热通过。
7. Gerber、钻孔、PDF、PNG 与概念等轴图是确定性审查输出，不是原生制造/3D 输出。

## 工程与实测规模

| 项目 | 实测值 | 证据 |
|---|---:|---|
| 板框 | 96.0 × 72.0 mm | `analysis/pcb.json` |
| 铜层 | 4：F.Cu / In1.Cu(GND) / In2.Cu(PWR) / B.Cu | 原始 PCB 与分析器 |
| 原理图器件 | 139 | `analysis/schematic.json` |
| PCB 封装 | 146（含 4 安装孔、3 基准点） | `analysis/pcb.json` |
| 网络 | 54 | `analysis/pcb.json` |
| 走线 / 过孔 / 覆铜 | 186 / 31 / 3 | `analysis/pcb.json` |
| 分析器未路由 | 37 | 明确制造阻断；路由器更保守口径为 40 |
| 测试点 | 54，信号网覆盖 50/50（100%） | TE-001 |
| Gerber / 钻孔 | 9 / 2 | `analysis/gerbers.json` |

原始 `.kicad_pro`、`.kicad_sch`、`.kicad_pcb` 与 `.kicad_dru` 均存在且由分析器成功解析；括号、四铜层、板框、内层 GND/PWR 覆铜、板边、网络类与安装孔的独立结构检查全部通过。

## 设计意图

- 24 V 入口：J1 → 0.75 A PTC → 串联 SS36 反接保护 → SMBJ33A TVS → 47 µF/100 nF → LMR16006X。
- 5 V：LMR16006X、22 µH、56 kΩ/10 kΩ 反馈。按 0.765 V 参考推算，目标约 5.049 V；仍需容差、启动、环路与瞬态仿真。
- 3.3 V：TLV75533，输入 1 µF、输出 4.7 µF，并配置局部去耦。
- 控制核心：STM32F072CBT6，USB FS、SWD、复位/BOOT、状态灯和完整测试点阵列。
- USB-C FS：双 5.1 kΩ Rd、VBUS PTC、USBLC6-2、双 22 Ω 串联电阻；ESD 器件附近增加地过孔后 EMC 工具降至 0 error。
- RS-485：THVD1450、可选 120 Ω 终端、默认未装偏置、SM712 防护与现场端子。
- 四路 0–10 V：每路 47 kΩ/10 kΩ 0.1% 分压，10 V 名义变为 1.754 V；等效 8.246 kΩ 与 10 nF 的一阶极点约 1.93 kHz，再经 1 kΩ 隔离和 TLV9064 缓冲。运放直接驱动 ADC 侧 1 nF 的稳定性仍需实测/仿真。

## 网络类与制造意图

| 网络类 | 线宽 | 间距 | 说明 |
|---|---:|---:|---|
| Power24V | 1.20 mm | 0.40 mm | 24 V 入口链路 |
| Power | 0.60 mm | 0.25 mm | 5 V / 3.3 V / 地 |
| USB_FS | 0.20 mm | 0.18 mm | 差分意图 0.20/0.15 mm，未做阻抗签核 |
| Analog | 0.25 mm | 0.25 mm | 四路模拟链路 |

以 1 oz 外层铜、10 °C 温升和旧式经验公式作筛选，1.20 mm 与 0.60 mm 线宽分别约 2.72 A、1.64 A；这不是 IPC-2152/板厂签核，也不能覆盖本次几何短路风险。

## 分析器实测

| 分析 | Error | Warning | Info | 解释 |
|---|---:|---:|---:|---|
| 原理图 | 1 | 4 | 42 | 采购覆盖为错误；4 个电源源声明为警告 |
| PCB full + proximity | 37 | 4 | 1 | 4 个端子距边 0.85 mm，为刻意边缘接口但仍需机械复核 |
| 交叉分析 | 5 | 2 | 1 | 工具把自由地过孔当作孤岛并派生回流间隙；不作自动豁免 |
| EMC 风险筛查 | 1 | 23 | 8 | CISPR 32 Class A 方向，风险分 77.5/100；不是合规预测 |
| 热估算（50 °C 环境） | 0 | 0 | 0 | 实际评估 0 个元件，结果不具证明力 |
| Gerber full | 0 | 0 | 1 | 9 层文件、2 钻孔文件结构可读 |
| 制造门禁 | 4 fail | 0 | 8 pass | 总体 FAIL |
| 独立线段几何 | 0 | 0 | 0 | 11,503 对唯一显式线段比较均无交叠/低净距；未路由仍阻断 |

原理图非信息项：+3V3A has no declared source；VBUS_USB has no declared source；VIN_FUSED has no declared source；VIN_PROT has no declared source；Sourcing blocker: BOM has <50% MPN coverage (9/52 unique parts). Board is not pre-fab ready.。  
PCB 警告：J1 is 0.85mm from board edge；J2 is 0.85mm from board edge；J3 is 0.85mm from board edge；J5 is 0.85mm from board edge。

制造门禁的 7 个 PCB 额外封装可由 4 个安装孔和 3 个基准点完全解释；28 个原理图额外网络是显式未连接引脚的隔离网络。该解释只消除“数量差异”的歧义，不消除采购与未路由阻断。

## 官方厂家资料核对

- [STM32F072CBT6 — STMicroelectronics](https://www.st.com/resource/en/datasheet/stm32f072cb.pdf)：DS9826 Rev 6, pp. 1, 34, 49: 2.0-3.6 V, USB FS, LQFP48 pinout, local decoupling。
- [LMR16006XDDCR — Texas Instruments](https://www.ti.com/lit/ds/symlink/lmr16006.pdf)：SNVSA24, pp. 1, 3, 9, 12, 18: 4-60 V, 600 mA, pinout, VFB=0.765 V, layout。
- [TLV75533PDBVR — Texas Instruments](https://www.ti.com/lit/ds/symlink/tlv755p.pdf)：SBVS320D, pp. 1, 3, 15: DBV pinout, 1 uF minimum nominal input/output capacitors。
- [USBLC6-2SC6 — STMicroelectronics](https://www.st.com/resource/en/datasheet/usblc6-2.pdf)：DS4260 Rev 7, pp. 1, 10-12: 1/6=I/O1, 2=GND, 3/4=I/O2, 5=VBUS。
- [THVD1450DR — Texas Instruments](https://www.ti.com/lit/ds/symlink/thvd1450.pdf)：SLLSEY3E, pp. 1, 5, 23, 29: SOIC-8 pinout, 3-5.5 V, half-duplex RS-485, layout。
- [TLV9064IPWR — Texas Instruments](https://www.ti.com/lit/ds/symlink/tlv9064.pdf)：SBOS839, p. 8 and application sections: TSSOP-14 pinout, 1.8-5.5 V RRIO quad op amp。
- [SMBJ33A — Littelfuse](https://www.littelfuse.com/~/media/electronics/datasheets/tvs_diodes/littelfuse_tvs_diode_smbj_datasheet.pdf.pdf)：SMBJ series manufacturer datasheet: SMBJ33A ratings table and DO-214AA package。

资料核对仅覆盖清单中的关键型号和所列页码/主题；其余通用件、替代料、降额、寿命与供应状态未覆盖，不能据此声称整板数据表闭环。

## 标准与合规边界

- 以 IPC-2221/2222 的通用几何与间距原则、IPC-2152 的载流评估思想、IPC-7351 的封装意图和 IPC-A-600/610 Class 2 目标作为设计输入；本包没有购买版标准逐条条款证据，也不声称认证。
- 24 V 功率域使用 0.40 mm 意图间距；最终严格重路由的显式线段几何在 0.18 mm 下限上无发现，但 40 个路由器口径网络仍未路由，且缺少原生 DRC，因此标准符合性继续阻断。
- CISPR 32 Class A 仅作为 EMC 风险筛查方向；外壳、线缆、接地、负载与实验室测量均未知。
- USB、ESD、RS-485、模拟精度和热性能必须在锁定板厂叠层、生产封装、额定负载与环境后重新审查。

## 导出物说明

- `outputs/gerbers/`：9 个 Gerber、PTH/NPTH 钻孔；仅审查证据。
- `outputs/bom.csv`、`outputs/positions.csv`：BOM 与坐标；缺料号项阻断采购。
- `outputs/review_drawing.pdf`：审查图纸，不是装配/制造签核图。
- `preview/board_top_white.svg`、`preview/board_top_white.png`：白底俯视预览；PNG 1800×1200，四角像素结构检查为白色。
- `preview/board_isometric_concept.svg`：概念等轴图；不得称为原生 3D。

## 放行条件

1. 使用固定版本的原生工具打开工程、重填覆铜，并取得 ERC=0、DRC=0 的报告。
2. 完成剩余 40 个路由器口径网络的无冲突布线，保持独立几何事件归零，并人工复核电源、USB、开关节点和模拟回流。
3. 将 BOM 生产料号覆盖提高到 100% 或为每个批准例外建立签字记录。
4. 锁定 USB-C 连接器、所有生产封装与 3D/机械边界。
5. 取得板厂叠层与阻抗计算，完成 USB 差分长度/间距签核。
6. 在额定输入、负载、环境与容差下完成电源/模拟仿真、热估算和样机测试。
7. 由原生工具重新导出 Gerber、钻孔、BOM、坐标、PDF 与 3D，并与工程哈希闭环。
8. 完成 EMC 预兼容测量后再评估合规。

状态锁只能由有权限的工程签核流程解除；当前任何自动结果都不得把 `accepted`、`ruleEnabled` 或 `fabricationReady` 改为 true。

## 路由判据差异

严格路由器仅在一个网络的全部不同焊盘坐标均被同一提交连接时计为完成，因此为 14 complete / 40 unrouted。PCB 分析器把内层平面和已有焊盘连通纳入较宽松统计，因此为 17 routed / 37 unrouted。报告和门禁采用两者中更保守的未路由口径，不用判据差异降低风险等级。
