﻿# AICAD PCB evidence-contract gate

- Status: **evidence_contract_incomplete**
- Disposition: blocker_report_only
- Evidence contract ready: false
- Independent evidence authenticity verified: false
- Native execution replayed by this QA: false
- Technical candidate artifacts exposed: false
- Production release eligible: false
- Artifact-set SHA-256: unavailable

## Evidence binding results

| Gate | Result |
|---|---|
| artifacts.expectedClosureHashesSubjectsKindsAndUniqueness | fail |
| intent.wholeIntent | fail |
| intent.schematicAuthority | fail |
| intent.stackupAndFabCapability | fail |
| intent.fabricatorCapabilitySnapshotAndOrderTimeRecheckPolicy | fail |
| intent.currentStandardsLedger | fail |
| intent.noRetiredSoleAuthority | fail |
| intent.officialPackageAuthority | fail |
| intent.officialFootprintDatasheetPin1AuthorityComplete | fail |
| intent.powerEnvironmentInterfacesAndAcceptanceAuthority | fail |
| intent.regulatorySafetyAndEnvironmentalApplicabilityResolved | fail |
| intent.productClassAssemblyClassAndAcceptanceCriteriaResolved | fail |
| intent.transientAbnormalAndImmunityProfilesFrozen | fail |
| design.schematicPcbNetlistParity | fail |
| design.padNetBidirectionalParity | fail |
| design.physicalReferenceFootprintParity | fail |
| design.footprintDatasheetPin1Parity | fail |
| design.symbolPinNumberFunctionElectricalTypeParity | fail |
| design.exactOrderedMpnAndSymbolAliasResolution | fail |
| design.netclassAssignmentCoverage | fail |
| design.creepageAndClearance | fail |
| design.stackup | fail |
| design.controlledImpedance | fail |
| design.completeRouting | fail |
| design.finalUnconnected | fail |
| design.zoneRefillCurrent | fail |
| design.zoneFillConnectivity | fail |
| design.boardOutline | fail |
| design.courtyardAndBoardEdgePlacement | fail |
| design.connectorKeepoutMountingGeometryFreeze | fail |
| design.connectorTerminalWireToolAndEnclosureAccessibility | fail |
| design.mountingFastenerHeadKeepoutAndHeightEnvelope | fail |
| design.powerDomainsAndReturnPaths | fail |
| design.componentRatingsDeratingAndWorstCase | fail |
| design.powerBudgetStartupSequencingAndFaultRecovery | fail |
| design.protectionCoordinationAndTransientEnergy | fail |
| design.analogAccuracyFilterClampAndAdcDriveBudget | fail |
| design.clockResetProgrammingAndProtocolConstraints | fail |
| design.groundingIsolationAndCommonModeBoundary | fail |
| design.testProgrammingAndDebugAccess | fail |
| manufacturingDefinition.bomComplete | fail |
| manufacturingDefinition.mpnCoverage | fail |
| manufacturingDefinition.bomValueQuantityFootprintMpnParity | fail |
| manufacturingDefinition.gerberClosure | fail |
| manufacturingDefinition.drillClosure | fail |
| manufacturingDefinition.jobFileClosure | fail |
| manufacturingDefinition.pickAndPlaceClosure | fail |
| manufacturingDefinition.assemblyDrawingClosure | fail |
| manufacturingDefinition.fabricationPlots | fail |
| manufacturingDefinition.assemblyOutputs | fail |
| manufacturingDefinition.native3dBoard | fail |
| manufacturingDefinition.bomCplReferenceParity | fail |
| manufacturingDefinition.pin1RotationSideAudit | fail |
| manufacturingDefinition.dnpPopulationLedger | fail |
| manufacturingDefinition.solderMaskPasteSilkscreenPolarityAndFabNotes | fail |
| manufacturingDefinition.platedNonplatedDrillSlotAndCastellationSemantics | fail |
| manufacturingDefinition.supplierLifecycleAndOrderTimeRecheckPolicy | fail |
| verification.kicadVersionRecorded | fail |
| verification.nativeProjectSourceHashBinding | fail |
| verification.nativeSchematicSourceHashBinding | fail |
| verification.nativeBoardSourceHashBinding | fail |
| verification.nativeErcErrors | fail |
| verification.nativeErcUnmanagedWarnings | fail |
| verification.nativeErcIgnoredCheckCount | fail |
| verification.nativeErcIgnoredChecksAudited | fail |
| verification.nativeProjectExclusionsEmptyOrAudited | fail |
| verification.nativeDrcErrors | fail |
| verification.nativeDrcUnmanagedWarnings | fail |
| verification.nativeDrcIgnoredCheckCount | fail |
| verification.nativeProjectExclusionCount | fail |
| verification.nativeDrcSchematicParityErrors | fail |
| verification.nativeDrcFootprintSymbolMismatchErrors | fail |
| verification.nativeDrcNetConflictErrors | fail |
| verification.nativeSymbolPinMappingErrors | fail |
| verification.nativeFootprintPadNumberMappingErrors | fail |
| verification.exclusionWaiverLedgerAllowedTypes | fail |
| verification.ercAndDrcAfterRefill | fail |
| verification.thermalAnalysis | fail |
| verification.emcAnalysis | fail |
| verification.signalIntegrity | fail |
| verification.powerIntegrity | fail |
| verification.circuitSimulation | fail |
| verification.simulationBoundaryDefined | fail |
| verification.functionalVerification | fail |
| verification.camSourceRevisionBinding | fail |
| verification.schematicVisualLegibilityAndPageUse | fail |
| verification.pcbFunctionalPlacementZonesAndAccessibility | fail |
| verification.board3dEnclosureConnectorAndHeightCollision | fail |
| verification.camIndependentReadbackAndLayerDrillClosure | fail |
| verification.outputManifestBidirectionalClosure | fail |
| host.nativeProjectSaveReopen | fail |
| host.nativeSourceSaveHash | fail |
| host.plotSourceBinding | fail |
| host.native3dReopen | fail |
| release.electricalReviewRecorded | fail |
| release.reviewerIdentityPresent | fail |
| release.reviewerCredentialPresent | fail |
| release.reviewScopeMatchesArtifactSet | fail |
| release.approvalRecordIdentifierPresent | fail |
| release.recordedApprovalSignaturePresent | fail |

## Blocking evidence-contract gates

- artifacts.expectedClosureHashesSubjectsKindsAndUniqueness
- intent.wholeIntent
- intent.schematicAuthority
- intent.stackupAndFabCapability
- intent.fabricatorCapabilitySnapshotAndOrderTimeRecheckPolicy
- intent.currentStandardsLedger
- intent.noRetiredSoleAuthority
- intent.officialPackageAuthority
- intent.officialFootprintDatasheetPin1AuthorityComplete
- intent.powerEnvironmentInterfacesAndAcceptanceAuthority
- intent.regulatorySafetyAndEnvironmentalApplicabilityResolved
- intent.productClassAssemblyClassAndAcceptanceCriteriaResolved
- intent.transientAbnormalAndImmunityProfilesFrozen
- design.schematicPcbNetlistParity
- design.padNetBidirectionalParity
- design.physicalReferenceFootprintParity
- design.footprintDatasheetPin1Parity
- design.symbolPinNumberFunctionElectricalTypeParity
- design.exactOrderedMpnAndSymbolAliasResolution
- design.netclassAssignmentCoverage
- design.creepageAndClearance
- design.stackup
- design.controlledImpedance
- design.completeRouting
- design.finalUnconnected
- design.zoneRefillCurrent
- design.zoneFillConnectivity
- design.boardOutline
- design.courtyardAndBoardEdgePlacement
- design.connectorKeepoutMountingGeometryFreeze
- design.connectorTerminalWireToolAndEnclosureAccessibility
- design.mountingFastenerHeadKeepoutAndHeightEnvelope
- design.powerDomainsAndReturnPaths
- design.componentRatingsDeratingAndWorstCase
- design.powerBudgetStartupSequencingAndFaultRecovery
- design.protectionCoordinationAndTransientEnergy
- design.analogAccuracyFilterClampAndAdcDriveBudget
- design.clockResetProgrammingAndProtocolConstraints
- design.groundingIsolationAndCommonModeBoundary
- design.testProgrammingAndDebugAccess
- manufacturingDefinition.bomComplete
- manufacturingDefinition.mpnCoverage
- manufacturingDefinition.bomValueQuantityFootprintMpnParity
- manufacturingDefinition.gerberClosure
- manufacturingDefinition.drillClosure
- manufacturingDefinition.jobFileClosure
- manufacturingDefinition.pickAndPlaceClosure
- manufacturingDefinition.assemblyDrawingClosure
- manufacturingDefinition.fabricationPlots
- manufacturingDefinition.assemblyOutputs
- manufacturingDefinition.native3dBoard
- manufacturingDefinition.bomCplReferenceParity
- manufacturingDefinition.pin1RotationSideAudit
- manufacturingDefinition.dnpPopulationLedger
- manufacturingDefinition.solderMaskPasteSilkscreenPolarityAndFabNotes
- manufacturingDefinition.platedNonplatedDrillSlotAndCastellationSemantics
- manufacturingDefinition.supplierLifecycleAndOrderTimeRecheckPolicy
- verification.kicadVersionRecorded
- verification.nativeProjectSourceHashBinding
- verification.nativeSchematicSourceHashBinding
- verification.nativeBoardSourceHashBinding
- verification.nativeErcErrors
- verification.nativeErcUnmanagedWarnings
- verification.nativeErcIgnoredCheckCount
- verification.nativeErcIgnoredChecksAudited
- verification.nativeProjectExclusionsEmptyOrAudited
- verification.nativeDrcErrors
- verification.nativeDrcUnmanagedWarnings
- verification.nativeDrcIgnoredCheckCount
- verification.nativeProjectExclusionCount
- verification.nativeDrcSchematicParityErrors
- verification.nativeDrcFootprintSymbolMismatchErrors
- verification.nativeDrcNetConflictErrors
- verification.nativeSymbolPinMappingErrors
- verification.nativeFootprintPadNumberMappingErrors
- verification.exclusionWaiverLedgerAllowedTypes
- verification.ercAndDrcAfterRefill
- verification.thermalAnalysis
- verification.emcAnalysis
- verification.signalIntegrity
- verification.powerIntegrity
- verification.circuitSimulation
- verification.simulationBoundaryDefined
- verification.functionalVerification
- verification.camSourceRevisionBinding
- verification.schematicVisualLegibilityAndPageUse
- verification.pcbFunctionalPlacementZonesAndAccessibility
- verification.board3dEnclosureConnectorAndHeightCollision
- verification.camIndependentReadbackAndLayerDrillClosure
- verification.outputManifestBidirectionalClosure
- host.nativeProjectSaveReopen
- host.nativeSourceSaveHash
- host.plotSourceBinding
- host.native3dReopen

## Recorded approval evidence not complete

These fields do not change the evidence-contract conclusion and do not authorize release.

- release.electricalReviewRecorded
- release.reviewerIdentityPresent
- release.reviewerCredentialPresent
- release.reviewScopeMatchesArtifactSet
- release.approvalRecordIdentifierPresent
- release.recordedApprovalSignaturePresent

Every non-release evidence-contract gate is non-compensatory.
Recorded approval evidence is not cryptographic trust-chain verification or production authorization.
Safety locks remain reviewOnly=true, accepted=false, ruleEnabled=false, packagingGated=true, comparativeSuperiorityClaimAllowed=false.
