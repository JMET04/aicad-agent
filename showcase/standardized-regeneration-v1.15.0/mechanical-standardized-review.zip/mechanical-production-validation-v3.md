﻿# AICAD Mechanical evidence-contract gate

- Status: **evidence_contract_ready**
- Disposition: evidence_contract_review_only
- Evidence contract ready: true
- Independent evidence authenticity verified: false
- Native execution replayed by this QA: false
- Technical candidate artifacts exposed: false
- Production release eligible: false
- Artifact-set SHA-256: 8017deadbeb039425a88ce9938698d27a8de0f4fd15ea4ab1f93a622119aac56

## Evidence binding results

| Gate | Result |
|---|---|
| artifacts.expectedClosureHashesSubjectsKindsAndUniqueness | pass |
| intent.wholeIntent | pass |
| intent.dimensionalAuthority | pass |
| intent.materialAuthority | pass |
| intent.processAuthority | pass |
| intent.standardsApplicabilityAndEditionResolved | pass |
| intent.materialAndFastenerPropertySourcesBound | pass |
| intent.operatingEnvelopeDutyCycleAndDesignLifeAuthority | pass |
| intent.assemblyConfigurationAndInterfaceAuthority | pass |
| intent.safetyRegulatoryAndRiskApplicabilityResolved | pass |
| intent.currentStandardsLedger | pass |
| intent.noRetiredSoleAuthority | pass |
| design.constraintCompile | pass |
| design.detailProof | pass |
| design.loadCasesAndServiceConditions | pass |
| design.analysisInputUnitsAndProvenance | pass |
| design.analysisRecomputedFromDeclaredInputs | pass |
| design.criticalLoadPathCoverage | pass |
| design.loadCombinationAndAbnormalCaseCoverage | pass |
| design.analysisEquationInputOutputMarginTrace | pass |
| design.strength | pass |
| design.stiffness | pass |
| design.fatigueApplicabilityAndResult | pass |
| design.factorOfSafety | pass |
| design.jointBearingAndEdgeChecks | pass |
| design.fastenerPreloadSlipAndCapacity | pass |
| design.bearingLife | pass |
| design.thermalEnvelope | pass |
| design.fitAndMatingInterfaces | pass |
| design.toleranceStack | pass |
| design.failureModesAndResidualRiskControls | pass |
| design.assemblyServiceAndToolClearance | pass |
| manufacturingDefinition.materialDesignation | pass |
| manufacturingDefinition.materialConditionAndHeatTreatment | pass |
| manufacturingDefinition.materialCertificateRequirementAndIncomingInspection | pass |
| manufacturingDefinition.generalAndFeatureTolerances | pass |
| manufacturingDefinition.gdandtDatumScheme | pass |
| manufacturingDefinition.surfaceRoughness | pass |
| manufacturingDefinition.stockAndPrimaryProcess | pass |
| manufacturingDefinition.fixturingFeasibility | pass |
| manufacturingDefinition.toolAccessibility | pass |
| manufacturingDefinition.coatingDimensionalCompensation | pass |
| manufacturingDefinition.processAndFinish | pass |
| manufacturingDefinition.threadsStandardPartsAndFastenerDefinition | pass |
| manufacturingDefinition.undefinedEdgesDeburrAndSharpEdgeControl | pass |
| manufacturingDefinition.assemblyBomItemRevisionAndQuantityClosure | pass |
| manufacturingDefinition.criticalCharacteristicProcessCapabilityAndMeasurementMethod | pass |
| manufacturingDefinition.inspectionPlan | pass |
| verification.drawingCompleteness | pass |
| verification.drawingFeatureBoundDimensionsDatumsFcfsFitsAndRoughness | pass |
| verification.drawingVisualLegibilityCollisionScaleAndSheetClosure | pass |
| verification.drawingModelInspectionCharacteristicParity | pass |
| verification.modelDrawingInspectionRevisionAndConfigurationIdentity | pass |
| verification.inspectionCharacteristicTrace | pass |
| verification.massAndMaterialReadback | pass |
| verification.nativeMaterialIdentityPersistence | pass |
| verification.nativeMaterialDatabaseAssignmentAndReadback | pass |
| verification.derivedOnlyOrCustomPropertyMaterialEvidenceCount | pass |
| verification.nativeCadSourceHashBinding | pass |
| verification.neutralStepSourceHashBinding | pass |
| verification.manufacturingDrawingSourceHashBinding | pass |
| host.nativeCadSaveReopen | pass |
| host.nativeSourceSaveHash | pass |
| host.nativeDrawingAssociativitySaveReopen | pass |
| host.semanticAnnotationPersistence | pass |
| host.topologyPersistence | pass |
| release.manufacturingReviewRecorded | fail |
| release.reviewerIdentityPresent | fail |
| release.reviewerCredentialPresent | fail |
| release.reviewScopeMatchesArtifactSet | fail |
| release.approvalRecordIdentifierPresent | fail |
| release.recordedApprovalSignaturePresent | fail |

## Recorded approval evidence not complete

These fields do not change the evidence-contract conclusion and do not authorize release.

- release.manufacturingReviewRecorded
- release.reviewerIdentityPresent
- release.reviewerCredentialPresent
- release.reviewScopeMatchesArtifactSet
- release.approvalRecordIdentifierPresent
- release.recordedApprovalSignaturePresent

Every non-release evidence-contract gate is non-compensatory.
Recorded approval evidence is not cryptographic trust-chain verification or production authorization.
Safety locks remain reviewOnly=true, accepted=false, ruleEnabled=false, packagingGated=true, comparativeSuperiorityClaimAllowed=false.
