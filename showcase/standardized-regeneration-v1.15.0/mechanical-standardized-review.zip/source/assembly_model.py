"""Controlled assembly model using only the local revision-K part sources."""
from __future__ import annotations

import math

from build123d import Align, Axis, Box, Compound, Cylinder, Location, Part

import carrier_model
import main_model
from model_common import PARAMETERS, ZMIN, annulus


ASSEMBLY_ID = "SRB160-SERVO-BRACKET-ASM"


def _bolt(diameter: float, length: float, head_diameter: float, head_height: float, label: str) -> Part:
    part = Cylinder(diameter / 2.0, length, align=ZMIN)
    part += Cylinder(head_diameter / 2.0, head_height, align=ZMIN).moved(Location((0, 0, -head_height)))
    part.label = label
    return part


def components() -> dict[str, object]:
    p = PARAMETERS
    main = p["mainPart"]
    carrier = p["carrierPart"]
    assembly = p["assembly"]
    bearing = p["bearing"]
    fasteners = p["fasteners"]
    offset = float(assembly["carrierGlobalOffsetZMm"])

    key_interface = p["shaftKeyInterface"]
    result: dict[str, object] = {
        "main": main_model.build_part(),
        "carrier": carrier_model.build_part().moved(Location((0, 0, offset))),
    }
    bearing_height = assembly["bearingGlobalZLimitsMm"][1] - assembly["bearingGlobalZLimitsMm"][0]
    result["bearing"] = annulus(bearing["outerDiameterMm"], bearing["boreMm"], bearing_height).moved(Location((0, 0, assembly["bearingGlobalZLimitsMm"][0])))
    result["ring"] = annulus(75.15, 68.8, 2.5).moved(Location((0, 0, offset + carrier["retainingGrooveNearWallMm"])))
    result["shim"] = annulus(72.0, 56.0, 0.3).moved(Location((0, 0, assembly["bearingGlobalZLimitsMm"][0] - 0.3)))

    shaft = Cylinder(15.0, 38.5, align=ZMIN).moved(Location((0, 0, -20.0)))
    shaft += Cylinder(20.0, 88.0, align=ZMIN).moved(Location((0, 0, 18.5)))
    shaft -= Box(key_interface["keyWidthMm"], 6.0, key_interface["keyLengthMm"], align=(Align.CENTER, Align.MIN, Align.MIN)).moved(Location((0, key_interface["shaftKeywayRadialStartMm"], key_interface["globalStartZMm"])))
    shaft.label = "SRB160-SHAFT-ICD"
    result["shaft"] = shaft

    key = Box(key_interface["keyWidthMm"], key_interface["keyHeightMm"], key_interface["keyLengthMm"], align=(Align.CENTER, Align.MIN, Align.MIN)).moved(Location((0, key_interface["shaftKeywayRadialStartMm"], key_interface["globalStartZMm"])))
    key.label = "DIN6885-KEY-12X8X45"
    result["key"] = key
    result["locknut"] = annulus(45.0, 30.0, 6.5).moved(Location((0, 0, -7.0)))

    reducer = Cylinder(62.0, 22.0, align=ZMIN).moved(Location((0, 0, 44.0)))
    reducer += Cylinder(32.0, 40.5, align=ZMIN).moved(Location((0, 0, 66.0)))
    reducer -= Cylinder(20.05, 62.7, align=ZMIN).moved(Location((0, 0, 43.9)))
    reducer -= Box(key_interface["hubKeywayWidthMm"], key_interface["hubKeywayRadialDepthMm"], 62.7, align=(Align.CENTER, Align.MIN, Align.MIN)).moved(Location((0, key_interface["hubKeywayRadialStartMm"], 43.9)))
    for index in range(int(main["reducerHoleCount"])):
        angle = math.radians(360.0 * index / main["reducerHoleCount"])
        reducer -= Cylinder(2.5, 21.2, align=ZMIN).moved(Location((main["reducerPcdMm"] / 2.0 * math.cos(angle), main["reducerPcdMm"] / 2.0 * math.sin(angle), 43.9)))
    reducer.label = "SRB160-REDUCER-ICD"
    result["reducer"] = reducer

    foundation = Box(180.0, 150.0, 30.0, align=ZMIN).moved(Location((0, 0, -30.0)))
    foundation -= Cylinder(57.0, 30.2, align=ZMIN).moved(Location((0, 0, -30.1)))
    for x, y in main["anchorCoordinatesMm"]:
        foundation -= Cylinder(fasteners["foundationM8"]["matingThreadRootDiameterMm"] / 2.0, 26.0, align=ZMIN).moved(Location((x, y, -26.0)))
    foundation.label = "SRB160-FOUNDATION-ICD"
    result["foundation"] = foundation

    m4_rows = []
    for index in range(fasteners["carrierM4"]["count"]):
        angle = math.radians(main["carrierThreadStartAngleDeg"] + 360.0 * index / fasteners["carrierM4"]["count"])
        m4_rows.append(_bolt(4.0, 16.0, 7.0, 4.0, f"M4-{index + 1}").moved(Location((fasteners["carrierM4"]["pcdMm"] / 2.0 * math.cos(angle), fasteners["carrierM4"]["pcdMm"] / 2.0 * math.sin(angle), -8.0))))
    result["m4"] = m4_rows

    m6_rows = []
    for index in range(fasteners["reducerM6"]["count"]):
        angle = math.radians(360.0 * index / fasteners["reducerM6"]["count"])
        m6_rows.append(_bolt(6.0, 55.0, 10.0, 6.0, f"M6-{index + 1}").moved(Location((fasteners["reducerM6"]["pcdMm"] / 2.0 * math.cos(angle), fasteners["reducerM6"]["pcdMm"] / 2.0 * math.sin(angle), 6.0))))
    result["m6"] = m6_rows

    m8_rows = []
    washer_rows = []
    for index, (x, y) in enumerate(main["anchorCoordinatesMm"]):
        washer_rows.append(annulus(16.0, 9.0, 1.6).moved(Location((x, y, 32.0))))
        m8_rows.append(_bolt(8.0, 55.0, 13.0, 8.0, f"M8-{index + 1}").rotate(Axis.X, 180.0).moved(Location((x, y, 33.6))))
    result["m8"] = m8_rows
    result["m8Washers"] = washer_rows
    return result


def build_assembly() -> Compound:
    rows = components()
    children = [rows[key] for key in ("main", "carrier", "bearing", "ring", "shim", "shaft", "key", "locknut", "reducer", "foundation")]
    children.extend(rows["m4"])
    children.extend(rows["m6"])
    children.extend(rows["m8"])
    children.extend(rows["m8Washers"])
    compound = Compound(children=children)
    compound.label = ASSEMBLY_ID
    return compound

