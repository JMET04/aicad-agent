"""Single-source build123d model for SRB160-CARRIER-001 revision K."""
from __future__ import annotations

from build123d import Cylinder, Location, Part

from model_common import PARAMETERS, ZMIN, cut_pattern, nominal


PART_ID = "SRB160-CARRIER-001"


def build_part() -> Part:
    carrier = PARAMETERS["carrierPart"]
    flange_z0, flange_z1 = carrier["flangeZLimitsMm"]
    barrel_z0, barrel_z1 = carrier["clearanceBarrelZLimitsMm"]
    band_z0, band_z1 = carrier["locatingBandZLimitsMm"]
    overall = float(band_z1)
    body = Cylinder(nominal(carrier["flangeOuterDiameterLimitsMm"]) / 2.0, flange_z1 - flange_z0, align=ZMIN).moved(Location((0, 0, flange_z0)))
    body += Cylinder(nominal(carrier["clearanceBarrelDiameterLimitsMm"]) / 2.0, barrel_z1 - barrel_z0, align=ZMIN).moved(Location((0, 0, barrel_z0)))
    body += Cylinder(nominal(carrier["locatingBandDiameterLimitsMm"]) / 2.0, band_z1 - band_z0, align=ZMIN).moved(Location((0, 0, band_z0)))

    body -= Cylinder(float(carrier["throughBoreDiameterMm"]) / 2.0, overall + 0.2, align=ZMIN).moved(Location((0, 0, -0.1)))
    body -= Cylinder(float(carrier["bearingSeatBasicDiameterMm"]) / 2.0, float(carrier["bearingShoulderZMm"]) + 0.1, align=ZMIN).moved(Location((0, 0, -0.1)))
    body -= Cylinder(nominal(carrier["retainingGrooveDiameterLimitsMm"]) / 2.0, nominal(carrier["retainingGrooveWidthLimitsMm"]), align=ZMIN).moved(Location((0, 0, float(carrier["retainingGrooveNearWallMm"]))))
    body = cut_pattern(
        body, nominal(carrier["clampClearanceDiameterLimitsMm"]), float(carrier["clampPcdMm"]),
        int(carrier["clampHoleCount"]), float(PARAMETERS["mainPart"]["carrierThreadStartAngleDeg"]),
        flange_z0 - 0.1, flange_z1 - flange_z0 + 0.2,
    )
    body = cut_pattern(
        body, float(carrier["reducerToolScallopDiameterMm"]), float(carrier["reducerToolScallopPcdMm"]),
        int(carrier["reducerToolScallopCount"]), float(carrier["reducerToolScallopStartAngleDeg"]),
        flange_z0 - 0.1, flange_z1 - flange_z0 + 0.2,
    )
    body.label = PART_ID
    return body

