"""Single-source build123d model for SRB160-BRACKET-001 revision K."""
from __future__ import annotations

import math

from build123d import Box, Cylinder, GeomType, Location, Part, fillet

from model_common import PARAMETERS, ZMIN, cut_pattern, nominal


PART_ID = "SRB160-BRACKET-001"


def build_part() -> Part:
    main = PARAMETERS["mainPart"]
    base_x, base_y, base_z = map(float, main["baseSizeMm"])
    boss_height = float(main["bossTopZMm"]) - base_z
    body = Box(base_x, base_y, base_z, align=ZMIN)
    body += Cylinder(float(main["bossOuterDiameterMm"]) / 2.0, boss_height, align=ZMIN).moved(Location((0, 0, base_z)))

    root_edges = [
        edge for edge in body.edges()
        if edge.geom_type == GeomType.CIRCLE
        and abs(edge.center().Z - base_z) < 1e-6
        and abs(edge.length - math.pi * float(main["bossOuterDiameterMm"])) < 1e-3
    ]
    if len(root_edges) != 1:
        raise RuntimeError(f"boss-root topology selection failed: expected 1 edge, observed {len(root_edges)}")
    body = fillet(root_edges, float(main["bossRootRadiusMm"]))

    clearance = main["carrierClearanceBore"]
    locating = main["carrierLocatingReceptacle"]
    continuation = main["shaftContinuationBore"]
    body -= Cylinder(nominal(clearance["diameterLimitsMm"]) / 2.0, clearance["zLimitsMm"][1] - clearance["zLimitsMm"][0], align=ZMIN).moved(Location((0, 0, clearance["zLimitsMm"][0])))
    body -= Cylinder(nominal(locating["diameterLimitsMm"]) / 2.0, locating["zLimitsMm"][1] - locating["zLimitsMm"][0], align=ZMIN).moved(Location((0, 0, locating["zLimitsMm"][0])))
    body -= Cylinder(float(continuation["diameterMm"]) / 2.0, continuation["zLimitsMm"][1] - continuation["zLimitsMm"][0], align=ZMIN).moved(Location((0, 0, continuation["zLimitsMm"][0])))

    body = cut_pattern(
        body, float(main["carrierThreadRootDiameterMm"]), float(main["carrierThreadPcdMm"]),
        int(main["carrierThreadCount"]), float(main["carrierThreadStartAngleDeg"]), 0.0,
        float(main["carrierThreadEngagementMm"]),
    )
    body = cut_pattern(
        body, float(main["reducerClearanceDiameterMm"]), float(main["reducerPcdMm"]),
        int(main["reducerHoleCount"]), 0.0, float(main["reducerCounterboreDepthMm"]) - 0.1,
        float(main["bossTopZMm"]) - float(main["reducerCounterboreDepthMm"]) + 0.2,
    )
    body = cut_pattern(
        body, float(main["reducerCounterboreDiameterMm"]), float(main["reducerPcdMm"]),
        int(main["reducerHoleCount"]), 0.0, -0.1, float(main["reducerCounterboreDepthMm"]) + 0.2,
    )
    body = cut_pattern(
        body, float(main["reducerDowelDiameterMm"]), float(main["reducerDowelPcdMm"]),
        int(main["reducerDowelCount"]), float(main["reducerDowelStartAngleDeg"]), base_z,
        float(main["bossTopZMm"]) - base_z + 0.1,
    )
    for x, y in main["anchorCoordinatesMm"]:
        body -= Cylinder(float(main["anchorClearanceDiameterMm"]) / 2.0, base_z + 0.2, align=ZMIN).moved(Location((x, y, -0.1)))
    body.label = PART_ID
    return body

