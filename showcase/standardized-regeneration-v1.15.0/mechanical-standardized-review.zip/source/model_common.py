"""Shared parameter access and geometry helpers for candidate K."""
from __future__ import annotations

import json
import math
from pathlib import Path

from build123d import Align, Cylinder, Location, Part


SOURCE_DIR = Path(__file__).resolve().parent
PARAMETERS_PATH = SOURCE_DIR / "design_parameters.json"
PARAMETERS = json.loads(PARAMETERS_PATH.read_text(encoding="utf-8"))
ZMIN = (Align.CENTER, Align.CENTER, Align.MIN)


def nominal(limits: list[float]) -> float:
    return (float(limits[0]) + float(limits[1])) / 2.0


def cut_pattern(
    body: Part,
    diameter: float,
    pcd: float,
    count: int,
    start_angle_deg: float,
    z: float,
    depth: float,
) -> Part:
    for index in range(count):
        angle = math.radians(start_angle_deg + 360.0 * index / count)
        cutter = Cylinder(diameter / 2.0, depth, align=ZMIN).moved(
            Location((pcd / 2.0 * math.cos(angle), pcd / 2.0 * math.sin(angle), z))
        )
        body -= cutter
    return body


def annulus(outer_diameter: float, inner_diameter: float, height: float) -> Part:
    return Cylinder(outer_diameter / 2.0, height, align=ZMIN) - Cylinder(inner_diameter / 2.0, height, align=ZMIN)

