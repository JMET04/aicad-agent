# 悬崖别墅三层钢结构诊断审计

- 生成器：1.12.0-diagnostic.1
- 设计依据 SHA256：`ebb707fa8fd492226aa15ea179db1de3f707a5605a172828bcfc90cf17047d50`
- 建筑修改器源 SHA256：`2348f84b9172e225229853f12ac6a1a91332cd1f96b3793104365284b851c929`
- 节点：52；构件：132
- 楼层构件：{"LF": 33, "MF": 50, "ROOF": 10, "UF": 39}
- 轴网：支承派生非等距；structuralModuleAuthority=false。
- 性质：review-only diagnostic；productionAuthority=false。

## 逐构件数学关系

| ID | 类型/角色 | 楼层 | 起节点 | 终节点 | 长度/mm | 截面/mm | 较早构件依赖 |
|---|---|---|---|---|---:|---:|---|
| `COL_LF_01` | column/gravity_column | LF | `NODE_0001` | `NODE_0002` | 3600.0 | 350×350 | 节点目录 |
| `COL_LF_02` | column/gravity_column | LF | `NODE_0003` | `NODE_0004` | 3600.0 | 350×350 | 节点目录 |
| `COL_LF_03` | column/gravity_column | LF | `NODE_0005` | `NODE_0006` | 3600.0 | 350×350 | 节点目录 |
| `COL_LF_04` | column/core_column | LF | `NODE_0007` | `NODE_0008` | 3600.0 | 450×450 | 节点目录 |
| `COL_LF_05` | column/core_column | LF | `NODE_0009` | `NODE_0010` | 3600.0 | 450×450 | 节点目录 |
| `COL_LF_06` | column/gravity_column | LF | `NODE_0011` | `NODE_0012` | 3600.0 | 350×350 | 节点目录 |
| `COL_LF_07` | column/core_column | LF | `NODE_0013` | `NODE_0014` | 3600.0 | 450×450 | 节点目录 |
| `COL_LF_08` | column/core_column | LF | `NODE_0015` | `NODE_0016` | 3600.0 | 450×450 | 节点目录 |
| `COL_LF_09` | column/gravity_column | LF | `NODE_0017` | `NODE_0018` | 3600.0 | 350×350 | 节点目录 |
| `COL_LF_10` | column/gravity_column | LF | `NODE_0019` | `NODE_0020` | 3600.0 | 350×350 | 节点目录 |
| `COL_MF_01` | column/gravity_column | MF | `NODE_0021` | `NODE_0022` | 3600.0 | 350×350 | 节点目录 |
| `COL_MF_02` | column/gravity_column | MF | `NODE_0023` | `NODE_0024` | 3600.0 | 350×350 | 节点目录 |
| `COL_MF_03` | column/gravity_column | MF | `NODE_0025` | `NODE_0026` | 3600.0 | 350×350 | 节点目录 |
| `COL_MF_04` | column/gravity_column | MF | `NODE_0027` | `NODE_0028` | 3600.0 | 350×350 | 节点目录 |
| `COL_MF_05` | column/core_column | MF | `NODE_0008` | `NODE_0029` | 3600.0 | 450×450 | 节点目录 |
| `COL_MF_06` | column/core_column | MF | `NODE_0010` | `NODE_0030` | 3600.0 | 450×450 | 节点目录 |
| `COL_MF_07` | column/core_column | MF | `NODE_0014` | `NODE_0031` | 3600.0 | 450×450 | 节点目录 |
| `COL_MF_08` | column/core_column | MF | `NODE_0016` | `NODE_0032` | 3600.0 | 450×450 | 节点目录 |
| `COL_MF_09` | column/gravity_column | MF | `NODE_0033` | `NODE_0034` | 3600.0 | 350×350 | 节点目录 |
| `COL_MF_10` | column/gravity_column | MF | `NODE_0035` | `NODE_0036` | 3600.0 | 350×350 | 节点目录 |
| `COL_MF_11` | column/gravity_column | MF | `NODE_0037` | `NODE_0038` | 3600.0 | 350×350 | 节点目录 |
| `COL_MF_12` | column/gravity_column | MF | `NODE_0039` | `NODE_0040` | 3600.0 | 350×350 | 节点目录 |
| `COL_UF_01` | column/gravity_column | UF | `NODE_0041` | `NODE_0042` | 3600.0 | 350×350 | 节点目录 |
| `COL_UF_02` | column/gravity_column | UF | `NODE_0043` | `NODE_0044` | 3600.0 | 350×350 | 节点目录 |
| `COL_UF_03` | column/core_column | UF | `NODE_0029` | `NODE_0045` | 3600.0 | 450×450 | 节点目录 |
| `COL_UF_04` | column/core_column | UF | `NODE_0030` | `NODE_0046` | 3600.0 | 450×450 | 节点目录 |
| `COL_UF_05` | column/core_column | UF | `NODE_0031` | `NODE_0047` | 3600.0 | 450×450 | 节点目录 |
| `COL_UF_06` | column/core_column | UF | `NODE_0032` | `NODE_0048` | 3600.0 | 450×450 | 节点目录 |
| `COL_UF_07` | column/gravity_column | UF | `NODE_0049` | `NODE_0050` | 3600.0 | 350×350 | 节点目录 |
| `COL_UF_08` | column/gravity_column | UF | `NODE_0051` | `NODE_0052` | 3600.0 | 350×350 | 节点目录 |
| `BEAM_LF_X_001` | beam/floor_beam | LF | `NODE_0001` | `NODE_0005` | 8400.0 | 300×500 | COL_LF_01, COL_LF_03 |
| `BEAM_LF_X_002` | beam/floor_beam | LF | `NODE_0005` | `NODE_0011` | 4200.0 | 300×500 | COL_LF_03, COL_LF_06 |
| `BEAM_LF_X_003` | beam/floor_beam | LF | `NODE_0011` | `NODE_0017` | 8400.0 | 300×500 | COL_LF_06, COL_LF_09 |
| `BEAM_LF_X_004` | beam/floor_beam | LF | `NODE_0007` | `NODE_0013` | 4200.0 | 300×500 | COL_LF_04, COL_LF_07 |
| `BEAM_LF_X_005` | beam/floor_beam | LF | `NODE_0003` | `NODE_0009` | 8400.0 | 300×500 | COL_LF_02, COL_LF_05 |
| `BEAM_LF_X_006` | beam/floor_beam | LF | `NODE_0009` | `NODE_0015` | 4200.0 | 300×500 | COL_LF_05, COL_LF_08 |
| `BEAM_LF_X_007` | beam/floor_beam | LF | `NODE_0015` | `NODE_0019` | 8400.0 | 300×500 | COL_LF_08, COL_LF_10 |
| `BEAM_LF_Y_001` | beam/floor_beam | LF | `NODE_0001` | `NODE_0003` | 8400.0 | 300×500 | COL_LF_01, COL_LF_02 |
| `BEAM_LF_Y_002` | beam/floor_beam | LF | `NODE_0005` | `NODE_0007` | 2100.0 | 300×500 | COL_LF_03, COL_LF_04 |
| `BEAM_LF_Y_003` | beam/floor_beam | LF | `NODE_0007` | `NODE_0009` | 6300.0 | 300×500 | COL_LF_04, COL_LF_05 |
| `BEAM_LF_Y_004` | beam/floor_beam | LF | `NODE_0011` | `NODE_0013` | 2100.0 | 300×500 | COL_LF_06, COL_LF_07 |
| `BEAM_LF_Y_005` | beam/floor_beam | LF | `NODE_0013` | `NODE_0015` | 6300.0 | 300×500 | COL_LF_07, COL_LF_08 |
| `BEAM_LF_Y_006` | beam/floor_beam | LF | `NODE_0017` | `NODE_0019` | 8400.0 | 300×500 | COL_LF_09, COL_LF_10 |
| `BEAM_MF_X_001` | beam/floor_beam | MF | `NODE_0021` | `NODE_0025` | 8400.0 | 300×500 | COL_MF_01, COL_MF_03 |
| `BEAM_MF_X_002` | beam/floor_beam | MF | `NODE_0025` | `NODE_0033` | 8400.0 | 300×500 | COL_MF_03, COL_MF_09 |
| `BEAM_MF_X_003` | beam/floor_beam | MF | `NODE_0033` | `NODE_0037` | 8400.0 | 300×500 | COL_MF_09, COL_MF_11 |
| `BEAM_MF_X_004` | beam/floor_beam | MF | `NODE_0002` | `NODE_0006` | 8400.0 | 300×500 | COL_LF_01, COL_LF_03 |
| `BEAM_MF_X_005` | beam/floor_beam | MF | `NODE_0006` | `NODE_0012` | 4200.0 | 300×500 | COL_LF_03, COL_LF_06 |
| `BEAM_MF_X_006` | beam/floor_beam | MF | `NODE_0012` | `NODE_0018` | 8400.0 | 300×500 | COL_LF_06, COL_LF_09 |
| `BEAM_MF_X_007` | beam/transfer_beam | MF | `NODE_0008` | `NODE_0014` | 4200.0 | 300×500 | COL_LF_04, COL_MF_05, COL_LF_07, COL_MF_07 |
| `BEAM_MF_X_008` | beam/floor_beam | MF | `NODE_0023` | `NODE_0004` | 2100.0 | 300×500 | COL_MF_02, COL_LF_02 |
| `BEAM_MF_X_009` | beam/floor_beam | MF | `NODE_0004` | `NODE_0027` | 6300.0 | 300×500 | COL_LF_02, COL_MF_04 |
| `BEAM_MF_X_010` | beam/transfer_beam | MF | `NODE_0027` | `NODE_0010` | 2100.0 | 300×500 | COL_MF_04, COL_LF_05, COL_MF_06 |
| `BEAM_MF_X_011` | beam/transfer_beam | MF | `NODE_0010` | `NODE_0016` | 4200.0 | 300×500 | COL_LF_05, COL_MF_06, COL_LF_08, COL_MF_08 |
| `BEAM_MF_X_012` | beam/transfer_beam | MF | `NODE_0016` | `NODE_0035` | 2100.0 | 300×500 | COL_LF_08, COL_MF_08, COL_MF_10 |
| `BEAM_MF_X_013` | beam/floor_beam | MF | `NODE_0035` | `NODE_0020` | 6300.0 | 300×500 | COL_MF_10, COL_LF_10 |
| `BEAM_MF_X_014` | beam/floor_beam | MF | `NODE_0020` | `NODE_0039` | 2100.0 | 300×500 | COL_LF_10, COL_MF_12 |
| `BEAM_MF_Y_001` | beam/floor_beam | MF | `NODE_0021` | `NODE_0023` | 10500.0 | 300×500 | COL_MF_01, COL_MF_02 |
| `BEAM_MF_Y_002` | beam/floor_beam | MF | `NODE_0002` | `NODE_0004` | 8400.0 | 300×500 | COL_LF_01, COL_LF_02 |
| `BEAM_MF_Y_003` | beam/floor_beam | MF | `NODE_0025` | `NODE_0027` | 10500.0 | 300×500 | COL_MF_03, COL_MF_04 |
| `BEAM_MF_Y_004` | beam/transfer_beam | MF | `NODE_0006` | `NODE_0008` | 2100.0 | 300×500 | COL_LF_03, COL_LF_04, COL_MF_05 |
| `BEAM_MF_Y_005` | beam/transfer_beam | MF | `NODE_0008` | `NODE_0010` | 6300.0 | 300×500 | COL_LF_04, COL_MF_05, COL_LF_05, COL_MF_06 |
| `BEAM_MF_Y_006` | beam/transfer_beam | MF | `NODE_0012` | `NODE_0014` | 2100.0 | 300×500 | COL_LF_06, COL_LF_07, COL_MF_07 |
| `BEAM_MF_Y_007` | beam/transfer_beam | MF | `NODE_0014` | `NODE_0016` | 6300.0 | 300×500 | COL_LF_07, COL_MF_07, COL_LF_08, COL_MF_08 |
| `BEAM_MF_Y_008` | beam/floor_beam | MF | `NODE_0033` | `NODE_0035` | 10500.0 | 300×500 | COL_MF_09, COL_MF_10 |
| `BEAM_MF_Y_009` | beam/floor_beam | MF | `NODE_0018` | `NODE_0020` | 8400.0 | 300×500 | COL_LF_09, COL_LF_10 |
| `BEAM_MF_Y_010` | beam/floor_beam | MF | `NODE_0037` | `NODE_0039` | 10500.0 | 300×500 | COL_MF_11, COL_MF_12 |
| `BEAM_UF_X_001` | beam/floor_beam | UF | `NODE_0022` | `NODE_0026` | 8400.0 | 300×500 | COL_MF_01, COL_MF_03 |
| `BEAM_UF_X_002` | beam/floor_beam | UF | `NODE_0026` | `NODE_0034` | 8400.0 | 300×500 | COL_MF_03, COL_MF_09 |
| `BEAM_UF_X_003` | beam/floor_beam | UF | `NODE_0034` | `NODE_0038` | 8400.0 | 300×500 | COL_MF_09, COL_MF_11 |
| `BEAM_UF_X_004` | beam/transfer_beam | UF | `NODE_0041` | `NODE_0029` | 8400.0 | 300×500 | COL_UF_01, COL_MF_05, COL_UF_03 |
| `BEAM_UF_X_005` | beam/transfer_beam | UF | `NODE_0029` | `NODE_0031` | 4200.0 | 300×500 | COL_MF_05, COL_UF_03, COL_MF_07, COL_UF_05 |
| `BEAM_UF_X_006` | beam/transfer_beam | UF | `NODE_0031` | `NODE_0049` | 8400.0 | 300×500 | COL_MF_07, COL_UF_05, COL_UF_07 |
| `BEAM_UF_X_007` | beam/floor_beam | UF | `NODE_0024` | `NODE_0043` | 2100.0 | 300×500 | COL_MF_02, COL_UF_02 |
| `BEAM_UF_X_008` | beam/floor_beam | UF | `NODE_0043` | `NODE_0028` | 6300.0 | 300×500 | COL_UF_02, COL_MF_04 |
| `BEAM_UF_X_009` | beam/transfer_beam | UF | `NODE_0028` | `NODE_0030` | 2100.0 | 300×500 | COL_MF_04, COL_MF_06, COL_UF_04 |
| `BEAM_UF_X_010` | beam/transfer_beam | UF | `NODE_0030` | `NODE_0032` | 4200.0 | 300×500 | COL_MF_06, COL_UF_04, COL_MF_08, COL_UF_06 |
| `BEAM_UF_X_011` | beam/transfer_beam | UF | `NODE_0032` | `NODE_0036` | 2100.0 | 300×500 | COL_MF_08, COL_UF_06, COL_MF_10 |
| `BEAM_UF_X_012` | beam/floor_beam | UF | `NODE_0036` | `NODE_0051` | 6300.0 | 300×500 | COL_MF_10, COL_UF_08 |
| `BEAM_UF_X_013` | beam/floor_beam | UF | `NODE_0051` | `NODE_0040` | 2100.0 | 300×500 | COL_UF_08, COL_MF_12 |
| `BEAM_UF_Y_001` | beam/floor_beam | UF | `NODE_0022` | `NODE_0024` | 10500.0 | 300×500 | COL_MF_01, COL_MF_02 |
| `BEAM_UF_Y_002` | beam/floor_beam | UF | `NODE_0041` | `NODE_0043` | 6300.0 | 300×500 | COL_UF_01, COL_UF_02 |
| `BEAM_UF_Y_003` | beam/floor_beam | UF | `NODE_0026` | `NODE_0028` | 10500.0 | 300×500 | COL_MF_03, COL_MF_04 |
| `BEAM_UF_Y_004` | beam/transfer_beam | UF | `NODE_0029` | `NODE_0030` | 6300.0 | 300×500 | COL_MF_05, COL_UF_03, COL_MF_06, COL_UF_04 |
| `BEAM_UF_Y_005` | beam/transfer_beam | UF | `NODE_0031` | `NODE_0032` | 6300.0 | 300×500 | COL_MF_07, COL_UF_05, COL_MF_08, COL_UF_06 |
| `BEAM_UF_Y_006` | beam/floor_beam | UF | `NODE_0034` | `NODE_0036` | 10500.0 | 300×500 | COL_MF_09, COL_MF_10 |
| `BEAM_UF_Y_007` | beam/floor_beam | UF | `NODE_0049` | `NODE_0051` | 6300.0 | 300×500 | COL_UF_07, COL_UF_08 |
| `BEAM_UF_Y_008` | beam/floor_beam | UF | `NODE_0038` | `NODE_0040` | 10500.0 | 300×500 | COL_MF_11, COL_MF_12 |
| `BEAM_ROOF_X_001` | beam/roof_beam | ROOF | `NODE_0042` | `NODE_0045` | 8400.0 | 300×500 | COL_UF_01, COL_UF_03 |
| `BEAM_ROOF_X_002` | beam/roof_beam | ROOF | `NODE_0045` | `NODE_0047` | 4200.0 | 300×500 | COL_UF_03, COL_UF_05 |
| `BEAM_ROOF_X_003` | beam/roof_beam | ROOF | `NODE_0047` | `NODE_0050` | 8400.0 | 300×500 | COL_UF_05, COL_UF_07 |
| `BEAM_ROOF_X_004` | beam/roof_beam | ROOF | `NODE_0044` | `NODE_0046` | 8400.0 | 300×500 | COL_UF_02, COL_UF_04 |
| `BEAM_ROOF_X_005` | beam/roof_beam | ROOF | `NODE_0046` | `NODE_0048` | 4200.0 | 300×500 | COL_UF_04, COL_UF_06 |
| `BEAM_ROOF_X_006` | beam/roof_beam | ROOF | `NODE_0048` | `NODE_0052` | 8400.0 | 300×500 | COL_UF_06, COL_UF_08 |
| `BEAM_ROOF_Y_001` | beam/roof_beam | ROOF | `NODE_0042` | `NODE_0044` | 6300.0 | 300×500 | COL_UF_01, COL_UF_02 |
| `BEAM_ROOF_Y_002` | beam/roof_beam | ROOF | `NODE_0045` | `NODE_0046` | 6300.0 | 300×500 | COL_UF_03, COL_UF_04 |
| `BEAM_ROOF_Y_003` | beam/roof_beam | ROOF | `NODE_0047` | `NODE_0048` | 6300.0 | 300×500 | COL_UF_05, COL_UF_06 |
| `BEAM_ROOF_Y_004` | beam/roof_beam | ROOF | `NODE_0050` | `NODE_0052` | 6300.0 | 300×500 | COL_UF_07, COL_UF_08 |
| `BRACE_LF_N_01A` | brace/north_facade_brace | LF | `NODE_0003` | `NODE_0010` | 9138.9 | 180×180 | COL_LF_02, COL_LF_05, BEAM_LF_X_005 |
| `BRACE_LF_N_01B` | brace/north_facade_brace | LF | `NODE_0009` | `NODE_0004` | 9138.9 | 180×180 | COL_LF_02, COL_LF_05, BEAM_LF_X_005, BRACE_LF_N_01A |
| `BRACE_LF_N_02A` | brace/north_facade_brace | LF | `NODE_0009` | `NODE_0016` | 5531.7 | 180×180 | COL_LF_05, COL_LF_08, BEAM_LF_X_006, BEAM_MF_X_011 |
| `BRACE_LF_N_02B` | brace/north_facade_brace | LF | `NODE_0015` | `NODE_0010` | 5531.7 | 180×180 | COL_LF_05, COL_LF_08, BEAM_LF_X_006, BEAM_MF_X_011, BRACE_LF_N_02A |
| `BRACE_LF_N_03A` | brace/north_facade_brace | LF | `NODE_0015` | `NODE_0020` | 9138.9 | 180×180 | COL_LF_08, COL_LF_10, BEAM_LF_X_007 |
| `BRACE_LF_N_03B` | brace/north_facade_brace | LF | `NODE_0019` | `NODE_0016` | 9138.9 | 180×180 | COL_LF_08, COL_LF_10, BEAM_LF_X_007, BRACE_LF_N_03A |
| `BRACE_LF_CORE_01A` | brace/core_brace | LF | `NODE_0007` | `NODE_0010` | 7256.0 | 200×200 | COL_LF_04, COL_LF_05, BEAM_LF_Y_003, BEAM_MF_Y_005 |
| `BRACE_LF_CORE_01B` | brace/core_brace | LF | `NODE_0009` | `NODE_0008` | 7256.0 | 200×200 | COL_LF_04, COL_LF_05, BEAM_LF_Y_003, BEAM_MF_Y_005, BRACE_LF_CORE_01A |
| `BRACE_LF_CORE_02A` | brace/core_brace | LF | `NODE_0013` | `NODE_0016` | 7256.0 | 200×200 | COL_LF_07, COL_LF_08, BEAM_LF_Y_005, BEAM_MF_Y_007 |
| `BRACE_LF_CORE_02B` | brace/core_brace | LF | `NODE_0015` | `NODE_0014` | 7256.0 | 200×200 | COL_LF_07, COL_LF_08, BEAM_LF_Y_005, BEAM_MF_Y_007, BRACE_LF_CORE_02A |
| `BRACE_MF_N_01A` | brace/north_facade_brace | MF | `NODE_0023` | `NODE_0028` | 9138.9 | 180×180 | COL_MF_02, COL_MF_04 |
| `BRACE_MF_N_01B` | brace/north_facade_brace | MF | `NODE_0027` | `NODE_0024` | 9138.9 | 180×180 | COL_MF_02, COL_MF_04, BRACE_MF_N_01A |
| `BRACE_MF_N_02A` | brace/north_facade_brace | MF | `NODE_0027` | `NODE_0030` | 4167.7 | 180×180 | COL_MF_04, COL_LF_05, COL_MF_06, BEAM_MF_X_010, BEAM_UF_X_009 |
| `BRACE_MF_N_02B` | brace/north_facade_brace | MF | `NODE_0010` | `NODE_0028` | 4167.7 | 180×180 | COL_MF_04, COL_LF_05, COL_MF_06, BEAM_MF_X_010, BEAM_UF_X_009, BRACE_MF_N_02A |
| `BRACE_MF_N_03A` | brace/north_facade_brace | MF | `NODE_0010` | `NODE_0032` | 5531.7 | 180×180 | COL_LF_05, COL_MF_06, COL_LF_08, COL_MF_08, BEAM_MF_X_011, BEAM_UF_X_010 |
| `BRACE_MF_N_03B` | brace/north_facade_brace | MF | `NODE_0016` | `NODE_0030` | 5531.7 | 180×180 | COL_LF_05, COL_MF_06, COL_LF_08, COL_MF_08, BEAM_MF_X_011, BEAM_UF_X_010, BRACE_MF_N_03A |
| `BRACE_MF_N_04A` | brace/north_facade_brace | MF | `NODE_0016` | `NODE_0036` | 4167.7 | 180×180 | COL_LF_08, COL_MF_08, COL_MF_10, BEAM_MF_X_012, BEAM_UF_X_011 |
| `BRACE_MF_N_04B` | brace/north_facade_brace | MF | `NODE_0035` | `NODE_0032` | 4167.7 | 180×180 | COL_LF_08, COL_MF_08, COL_MF_10, BEAM_MF_X_012, BEAM_UF_X_011, BRACE_MF_N_04A |
| `BRACE_MF_N_05A` | brace/north_facade_brace | MF | `NODE_0035` | `NODE_0040` | 9138.9 | 180×180 | COL_MF_10, COL_MF_12 |
| `BRACE_MF_N_05B` | brace/north_facade_brace | MF | `NODE_0039` | `NODE_0036` | 9138.9 | 180×180 | COL_MF_10, COL_MF_12, BRACE_MF_N_05A |
| `BRACE_MF_CORE_01A` | brace/core_brace | MF | `NODE_0008` | `NODE_0030` | 7256.0 | 200×200 | COL_LF_04, COL_MF_05, COL_LF_05, COL_MF_06, BEAM_MF_Y_005, BEAM_UF_Y_004 |
| `BRACE_MF_CORE_01B` | brace/core_brace | MF | `NODE_0010` | `NODE_0029` | 7256.0 | 200×200 | COL_LF_04, COL_MF_05, COL_LF_05, COL_MF_06, BEAM_MF_Y_005, BEAM_UF_Y_004, BRACE_MF_CORE_01A |
| `BRACE_MF_CORE_02A` | brace/core_brace | MF | `NODE_0014` | `NODE_0032` | 7256.0 | 200×200 | COL_LF_07, COL_MF_07, COL_LF_08, COL_MF_08, BEAM_MF_Y_007, BEAM_UF_Y_005 |
| `BRACE_MF_CORE_02B` | brace/core_brace | MF | `NODE_0016` | `NODE_0031` | 7256.0 | 200×200 | COL_LF_07, COL_MF_07, COL_LF_08, COL_MF_08, BEAM_MF_Y_007, BEAM_UF_Y_005, BRACE_MF_CORE_02A |
| `BRACE_UF_N_01A` | brace/north_facade_brace | UF | `NODE_0043` | `NODE_0046` | 9138.9 | 180×180 | COL_UF_02, COL_MF_06, COL_UF_04, BEAM_ROOF_X_004 |
| `BRACE_UF_N_01B` | brace/north_facade_brace | UF | `NODE_0030` | `NODE_0044` | 9138.9 | 180×180 | COL_UF_02, COL_MF_06, COL_UF_04, BEAM_ROOF_X_004, BRACE_UF_N_01A |
| `BRACE_UF_N_02A` | brace/north_facade_brace | UF | `NODE_0030` | `NODE_0048` | 5531.7 | 180×180 | COL_MF_06, COL_UF_04, COL_MF_08, COL_UF_06, BEAM_UF_X_010, BEAM_ROOF_X_005 |
| `BRACE_UF_N_02B` | brace/north_facade_brace | UF | `NODE_0032` | `NODE_0046` | 5531.7 | 180×180 | COL_MF_06, COL_UF_04, COL_MF_08, COL_UF_06, BEAM_UF_X_010, BEAM_ROOF_X_005, BRACE_UF_N_02A |
| `BRACE_UF_N_03A` | brace/north_facade_brace | UF | `NODE_0032` | `NODE_0052` | 9138.9 | 180×180 | COL_MF_08, COL_UF_06, COL_UF_08, BEAM_ROOF_X_006 |
| `BRACE_UF_N_03B` | brace/north_facade_brace | UF | `NODE_0051` | `NODE_0048` | 9138.9 | 180×180 | COL_MF_08, COL_UF_06, COL_UF_08, BEAM_ROOF_X_006, BRACE_UF_N_03A |
| `BRACE_UF_CORE_01A` | brace/core_brace | UF | `NODE_0029` | `NODE_0046` | 7256.0 | 200×200 | COL_MF_05, COL_UF_03, COL_MF_06, COL_UF_04, BEAM_UF_Y_004, BEAM_ROOF_Y_002 |
| `BRACE_UF_CORE_01B` | brace/core_brace | UF | `NODE_0030` | `NODE_0045` | 7256.0 | 200×200 | COL_MF_05, COL_UF_03, COL_MF_06, COL_UF_04, BEAM_UF_Y_004, BEAM_ROOF_Y_002, BRACE_UF_CORE_01A |
| `BRACE_UF_CORE_02A` | brace/core_brace | UF | `NODE_0031` | `NODE_0048` | 7256.0 | 200×200 | COL_MF_07, COL_UF_05, COL_MF_08, COL_UF_06, BEAM_UF_Y_005, BEAM_ROOF_Y_003 |
| `BRACE_UF_CORE_02B` | brace/core_brace | UF | `NODE_0032` | `NODE_0047` | 7256.0 | 200×200 | COL_MF_07, COL_UF_05, COL_MF_08, COL_UF_06, BEAM_UF_Y_005, BEAM_ROOF_Y_003, BRACE_UF_CORE_02A |

## 必须专业复核

- 构件截面、节点、连接、整体稳定与渐进倒塌。
- 岩土、基础、边坡、悬挑与泳池荷载。
- 风震、耐火、海盐腐蚀与施工阶段。
